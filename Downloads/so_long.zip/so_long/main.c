#include "minilibx/mlx.h"

int main(int ac, char **av)
{
    //t_map mapper;
    if (ac == 2)
    {
        checker(av[1]);

    }
}

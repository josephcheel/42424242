#include <stdio.h>

void ft_print_numbers(void);

int main()
{
	ft_print_numbers();
	return 0;
}

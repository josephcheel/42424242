#include "so_long.h"

t_map   map_array(t_map mapper)
{
    int fd;
    int i;
    char **map_array;

    mapper.y = 0;
    fd = open(mapper.map_filename, O_RDONLY);
    while (1)
    {
        mapper.map_array[mapper.y] = get_next_line(fd);
        if (mapper.map_array[mapper.y] == NULL)
            error_array();
        mapper.y++;
    }
    mapper.map_array[mapper.y] = NULL;
    return (mapper);
}
#include <stdio.h>

void ft_print_alphabet(void);

int main()
{
	ft_print_alphabet();
	return 0;
}

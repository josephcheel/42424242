#include <stdio.h>

void ft_print_combn(int n);

int main()
{
	int n = 10;
	ft_print_combn(n);
}

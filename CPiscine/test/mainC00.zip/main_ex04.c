#include <stdio.h>

void ft_is_negative(int n);

int main()
{
	int c;
	c = -30;
	ft_is_negative(c);
	return 0;
}

#include "so_long.h"

t_map map_checker(char *map)
{
    t_map mapper;

    mapper.map_filename = map;
    checker_file(map);
    mapper = map_array(mapper);
    checker_wall(mapper);
    checker_one_param();
}

void checker_file(char *map)
{
    if (!ft_strnstr(map, ".ber", ft_strlen(map)))
        error_filename();
}

void    checker_one_param()
{

}

void check_wall(t_map mapper)
{
    int i;
    int y;

    i = 0;
    while (mapper.map_array[1][i] == '1')
        i++; 
    if (!mapper.map_array[1][i] == '\n')
        error_wall();
    y = 2;
    while (y < mapper.y - 1)
    {
        if (mapper.map_array[y][1] != '1' || 
            mapper.map_array[y][mapper.y] != '1')
            error_wall();
        y++;
    }
    i = 0;
    while (mapper.map_array[mapper.y - 1][i] == '1')
        i++;
    if (!mapper.map_array[mapper.y - 1][i] == '\0')
        error_wall();
}
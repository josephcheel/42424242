#include <stdio.h>
void	ft_ft(int *nbr);

int		main(void)
{
	int	a_number;

	ft_ft(&a_number);
	printf("%d", a_number);
	return (0);
}

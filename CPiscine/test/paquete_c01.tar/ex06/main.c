#include <stdio.h>
int	ft_strlen(char *str);

int	main() {
	printf("hola %d\n", ft_strlen("hola"));
	printf("juanito %d\n", ft_strlen("juanito"));
	printf("'' %d\n", ft_strlen(""));
	printf("adios %d\n", ft_strlen("adios"));
}


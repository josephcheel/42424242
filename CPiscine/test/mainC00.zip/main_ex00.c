#include <stdio.h>

void	ft_putchar(char c);

int main()
{
	char c = 'a';
	ft_putchar(c);
}

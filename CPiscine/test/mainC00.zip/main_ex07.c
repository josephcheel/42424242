#include <stdio.h>

void ft_putnbr(int nb);

int main()
{
	int c;
	c = -114;
	ft_putnbr(c);
	return 0;
}

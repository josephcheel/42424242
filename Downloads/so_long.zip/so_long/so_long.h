#ifndef SO_LONG_H
# define SO_LONG_H

# include "libft/libft.h"
# include "get_next_line/get_next_line.h"
# include <unistd.h>
# include <fcntl.h>


typedef struct s_map
{
    int fd;
    char **map_array;
    char *map_filename;
    int y;
    int x; //without '\n'
}t_map;

t_map   map_array(mapper);

#endif
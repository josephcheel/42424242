void ft_putstr(char *str);

int main(void)
{
	char hola[] = "hola";
	ft_putstr(hola);
}

#include <stdio.h>

void ft_print_reverse_alphabet(void);

int main()
{
	ft_print_reverse_alphabet();
	return 0;
}
